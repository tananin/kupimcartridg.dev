Static Elements Manager for MODX

Description

This extra provides advanced batch management static elements (chunks, plugins, snippets, templates) of the website running on MODX CMF.

Get even more Creative freedom™!

Features

- Quick elements creation from one place in Manager.
- Auto-creation elements from files.
- Synchronisation of elements between file system and DB.

Latest Changes

For details read the complete changelog.

Copyright

Static Elements Manager for MODX is authored by Ivan Klimchuk and copyright 2012-2013 by LOVATA Group, LLC.

All rights reserved.

License

Static Elements Manager for MODX is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

GNU General Public License v2

Thank you for using Static Elements Manager for MODX!

Company: LOVATA Group <info@lovata.com>