<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6ee9bdb9fcc69148dc8dac9f55e0ab27',
      'native_key' => 'vapor',
      'filename' => 'modNamespace/40b0d0cdca3da3ab1f98c80b73e8f555.vehicle',
      'namespace' => 'vapor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '24398bda2093ac9455f11a5c52506c2b',
      'native_key' => 1,
      'filename' => 'modCategory/9088d2d11803beebfb00b883a8530bf1.vehicle',
      'namespace' => 'vapor',
    ),
  ),
);